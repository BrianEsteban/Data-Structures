/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dragon;

import java.awt.event.KeyEvent;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author BRIAN
 */
public class Dragon {
    Node head = null;
    
    /**
     * Verifica si está o no vacía la lista
     * @return true si la lista está vacía y false de lo contrario
     */
    public boolean isEmpty()
    { 
        return head == null ? true : false;
    }
    
    /**
     * Mientras haya un elemento (nodo) siguiente sigue haciendo el ciclo para imprimir cada uno.
     */
    public void printList()
    {
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        Node temp = head;
        try
        {
            bw.write("Grades: \n");
            while(temp != null)
            {
                bw.write(temp.toString());
                temp = temp.next;
            }
            bw.flush();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    /**
     * Inserta el nodo al inicio y lo apunta a la cabeza de la lista
     * @param newsequence 
     */
    public void insertAtBegin(Node newsequence)
    {
        newsequence.next = head;
        head = newsequence;
    }
    
    /**
     * Si la lista no es vacía, temp es iterado hasta que apunte a null, y allí inserta al nodo.
     * @param newsequence 
     */
    public void insertAtEnd(Node newsequence)
    {
        if (isEmpty()) 
            head = newsequence;
        else
        {
            Node temp = head;
            while(temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newsequence;
        }    
    }
    
    /**
     * Conociendo la posición en la que se quiere insertar el nodo, se itera n veces, y se fijan los apuntadores.
     * @param newsequence
     * @param n 
     */
    public void insertAt(Node newsequence, int n)
    {
        Node temp = head;
        
        for (int i = 0; i < n-1; i++) {
            temp = temp.next;
        }
        newsequence.next = temp.next;
        temp.next = newsequence;
    }
    
    /**
     * Funciona.
     * Conociendo la posición en la que se quiere insertar el nodo, se itera n veces, y se fijan los apuntadores.
     * @param newnode
     * @param index
     */
    public void insertAtIndex(Node newnode)
    {
        if (newnode.days == 0) 
        {
            newnode.next = head;
            head = newnode;
        }
        else
        {
            Node temp = head;
            for (int i = 0; i < newnode.days-1; i++) 
                temp = temp.next;
            
            newnode.next = temp.next;
            temp.next = newnode;
        }
    }
    
    public void deleteAtBegin()
    {
        Node temp = head;
        head = head.next;
        temp = null;
        System.gc();
    }
    
    public void deleteAtEnd()
    {
        if (isEmpty()) 
            System.out.println("No hay nada que eliminar");
        else {
            Node toDelete = head;
            Node temp = toDelete;
            while(toDelete.next != null)
            {
                temp = toDelete;
                toDelete = toDelete.next;
            }
            temp.next = null;
            System.gc();  
        }    
    }
    
    public void deleteAt(int n)
    {
        Node temp = head;
        Node toDelete;
        for (int i = 0; i < n-1; i++) 
        {
            temp = temp.next;
        }
        toDelete = temp.next;
        temp.next = temp.next.next;
        toDelete = null;
        System.gc();
    }
    
    public int entrenar(Node newNode)
    {
        int count = 0;
        while(newNode.days > 0)
        {
            newNode.days--;
            count ++;
        }
        return count;
    }
    
    public void multa()
    {
        Node temp = head;
        while(temp.next != null && temp.days > 0)
        {
            
            temp = temp.next;
        }
    }
    
    public void keyTyped(KeyEvent e){}
    
    public boolean keyPressed(KeyEvent e){
        if(e.getKeyCode()==KeyEvent.VK_ENTER)
            return true;        
        else
            return false;
     }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Dragon list = new Dragon();
        String enterkey = sc.nextLine();
        while(sc.hasNextInt())
        {
            int days = sc.nextInt();
            int fine = sc.nextInt();
            list.insertAtEnd(new Node(days, fine));
            if (enterkey.isEmpty()) {
                 break;
            }
        }
        
        list.printList();
        
    }
}
