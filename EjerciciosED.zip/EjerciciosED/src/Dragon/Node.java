/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dragon;

/**
 *
 * @author BRIAN
 */
public class Node {
    int days;
    int fine;
    
    Node next;

    public Node() {}

    public Node(int days, int fine) {
        this.days = days;
        this.fine = fine;
    }

    @Override
    public String toString() {
        return "days: " + days + " fine: " + fine ;
    }
    
    
}
