/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Phoenix;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.Scanner;

/**
 *
 * @author BRIAN
 */
public class Phoenix {
    Node head = null;
    
   /**
    * Verifica si la pila tiene elementos o no
    * @return false si la pila tiene elementos, de lo contrario true
    */
    public boolean isEmpty()
    {
        return head == null ? true : false;
    }
    
   /**
    * Imprime los elementos que existan, de la forma FILO(First Input Last Output)
    */ 
    public void printStack()
    {
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        try
        {
            while(!isEmpty())
            {
                bw.write(pop());
            }
            bw.flush();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    /**
     * El método peek retorna la información solamente del último nodo insertado
     * @return información de los parámetros que tenga el nodo temp
     */
    public String peek()
    {
        Node temp = head;
        String info = temp.toString();
        return info;
    }      
    
   /**
    * siguiendo los parámetros de las pilas, sólo se podrá insertar elementos al inicio, y este a su vez se convertirá en la cabeza.
    * @param newNode 
    */
    public void push(Node newNode) //insertar
    {
        newNode.next = head;
        head = newNode;
    }
    
   /**
    * Pop borra el elemento que hasta el momento sea la cabeza. Como se eleminará este elemento, la cabeza ahora será 
    * al que estaba apuntando, y desaparecerá el primer elemento.
    * @return la información del elemento eliminado.
    */ 
    public String pop() 
    {
        Node temp = head;
        head = head.next;
        
        String info=temp.toString();
        temp = null;
        System.gc();
        return info;
    }
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n_stacks = sc.nextInt();
        
        for (int i = 0; i < n_stacks; i++) {
            Phoenix stack = new Phoenix();
            int fighters  = sc.nextInt();
            for (int j = 0; j < fighters; j++) {
                int heigth = sc.nextInt();
                stack.push(new Node(heigth));
            }
            stack.printStack();
            
            int n_instructions = sc.nextInt();
            for (int j = 0; j < n_instructions; j++) {
                int instruction = sc.nextInt();
                
                switch(instruction)
                {
                    case 0:
                        int eliminar = sc.nextInt();
                        if (i-1 == eliminar ) {
                            
                        }
                }
            }
        }
    }
}
