/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Market;

import java.io.*;
import java.util.Scanner;

/**
 * Going to the Market tiene como objetivo final hacer la cuenta total de los productos según su precio y cantidad.
 * Se utilizan listas para solucionar el problema.
 * @author Brian Esteban Barreto Cardozo
 */
public class Market {
    Node head = null;
    
     /**
     * Verifica si está o no vacía la lista
     * @return true si la lista está vacía y false de lo contrario
     */
    public boolean isEmpty()
    { 
        return head == null ? true : false;
    }
    
    /**
     * Conociendo la posición en la que se quiere insertar el nodo, se itera n veces, y se fijan los apuntadores.
     * @param newnode
     * @param index
     */
    public void insertAt(Node newnode, int index)
    {
        if (index == 0) 
        {
            newnode.next = head;
            head = newnode;
        }
        else
        {
            Node temp = head;
            for (int i = 0; i < index-1; i++) 
                temp = temp.next;
            
            newnode.next = temp.next;
            temp.next = newnode;
        }
    }
    
    /**
     * A partir del nombre del producto se obtiene el precio, mientras haya nodos y el nombre no coincida con alguno
     * de los que anteriormente se insertaron, seguirá recorriendo.
     * @param name
     * @return 
     */
    public double priceSearch(String name)
    {
        if (isEmpty()) 
            return 0;
        else
        {
            Node temp = head;
            try
            {
                while(!temp.product_name.equals(name) && temp.next != null)
                    temp = temp.next;
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return temp.price;            
        }    
    }
    
    /**
     * mientras el número de casos sea mayor a cero se seguirá el proceso; primero, con un ciclo insertar en posiciones específicas los
     * nodos que tienen los parámetros de nombre y precio de los productos, enseguida se halla el precio de los productos que se 
     * comprarán con el método priceSearch y se multiplican por la cantidad, todo esto se va sumando para finalmente imprimir el total.
     * @param args 
     */
    public static void main(String[] args) throws IOException 
    {
        Market list = new Market();
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        double total;
        
        while(cases > 0)
        {
            total = 0;
            int products = sc.nextInt();
            for (int i = 0; i < products; i++) 
            {
                String name = sc.next();
                double price = sc.nextDouble();
                Node product_i = new Node(name, price);
                list.insertAt(product_i, i);
            }

            int shopping = sc.nextInt();
                
            for (int i = 0; i < shopping; i++) 
            {
                String name = sc.next();
                int amount = sc.nextInt();
                total += list.priceSearch(name) * amount;
            }   
           
            bw.write("R$ " + total + "\n");
            bw.flush();
            cases--;
        }   
    }
}

/*
//Entradas:
2 
4 
mamao 2,19 
cebola 3,10 
tomate 2,80 
uva 2,73 
3 
mamao 2 
tomate 1 
uva 3 
5 
morango 6,70 
repolho 1,12 
brocolis 1,71 
tomate 2,80 
cebola 2,81 4 
brocolis 2 
tomate 1 
cebola 1 
morango 1

//Respuesta: 
R$ 15.37
R$ 15.73
*/