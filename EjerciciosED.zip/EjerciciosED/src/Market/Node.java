/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Market;

/**
 *
 * @author BRIAN
 */
public class Node {
    String product_name;
    double price;
    //Apuntador
    Node next;
    
    public Node(){}

    public Node(String product_name, double price) {
        this.product_name = product_name;
        this.price = price;
    }
}
