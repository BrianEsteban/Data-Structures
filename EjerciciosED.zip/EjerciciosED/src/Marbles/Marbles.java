/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Marbles;

import java.io.*;
import java.util.Scanner;
/**
 * Where is the marble lo que busca es hallar la posicion de una o varias canicas en donde se da la cantidad de canicas y el numero
 * de busquedas que se deben hacer. Se llaman un método de ordenamiento como lo es bubleSort y un método de búsqueda como binarySearch.
 * @author Brian Esteban Barreto
 */
public class Marbles {
    
   /**
    * bubleSort es un metodo de ordenamiento tradicional. Compara elementos y realiza un cambio(swap) si se cumple la condicion 
    * de que sea mayor el que se encuentra en la posicion i al que se encuentra en la posicion i+1. 
    * @param unsorted
    * @return arreglo ordenado
    */
    public int[] bubleSort(int[] unsorted)
    {
        boolean swap = false;
        int temp;     
        do
        {
            swap = false;
            for (int i = 0; i < (unsorted.length - 1); i++) {
                if (unsorted[i] > unsorted[i+1]) {
                    temp = unsorted[i];
                    unsorted[i] = unsorted[i+1];
                    unsorted[i+1] = temp;
                    swap=true;
                }
            }
        }while(swap);
        return null;
    }
    
   /**
    * binarySearch no recursivo, va descartando la mitad del arreglo preguntando si x es mayor o menor a middlePoint.
    * Esto lo sigue haciendo el ciclo hasta hallar x
    * @param sorted
    * @param x
    * @return posicion del arreglo en donde se encuentra x, si no está -1.
    */  
    public String binarySearch(int sorted[], int x)
    {
        int lowerBound = 1;
        int upperBound = sorted.length;
        String index = x + " not found" + "\n";
        
        while(lowerBound < upperBound)
        {
            int middlePoint = (lowerBound + upperBound) / 2;
            if (x == sorted[middlePoint]) {
                index = x  + " found at "  + middlePoint;
                break;
            }
            else
            {
                if (x < middlePoint) 
                    upperBound = middlePoint - 1;
                else
                    lowerBound = middlePoint + 1;
            }
        }
        if ((lowerBound == upperBound) && sorted[lowerBound] == x)
            index = x + " found at " + lowerBound + "\n";
        
        return index;
    }
    
   /**
    * Se requieren principalmente de dos datos; el número de canicas para hacer el primer ciclo for con ese límite e ir guardando 
    * el número de las canicas en un arreglo y luego ordenarlo, el segundo dato es el numero de consultas, con este se hace el segundo
    * ciclo for donde se llama inmediantamente el método de búsqueda binaria para que vaya hallando la posicion de cierta cantidad de casos
    * @param args
    * @throws IOException 
    */
    public static void main(String[] args) throws IOException 
    {
        Marbles marble = new Marbles();    
        
        //BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        Scanner sc = new Scanner(System.in);
        
        int marbles = sc.nextInt();  //numero de canicas
        int queries = sc.nextInt();  //numero de consultas
        
        while(marbles != 0 && queries !=0)
        {
            int[] unsorted = new int[marbles + 1];
            
            for (int i = 1; i < marbles + 1; i++)
                unsorted[i] = sc.nextInt();
        
            marble.bubleSort(unsorted);
        
            for (int i = 0; i < queries; i++) 
            {
                int x = sc.nextInt();
                int ncase = i+1;
                bw.write("CASE# " + ncase + ":" + "\n");
                bw.write(marble.binarySearch(unsorted, x) + "\n");
                bw.flush();
            }
            marbles = sc.nextInt();  
            queries = sc.nextInt(); 
        }  
        bw.close();
    }
}

/*
//Entradas:
4 1
2 
3 
5 
1
5
Respuesta:
CASE# 1:
5 found at 4
//Entradas:
5 2
1 
3
3
3
1
2
Respuestas:
CASE# 1:
2 not found

3
CASE# 2:
3 found at 3

//Entradas:
0 0
//Fin
 */