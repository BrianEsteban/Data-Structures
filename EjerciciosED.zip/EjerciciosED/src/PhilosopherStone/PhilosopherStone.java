package PhilosopherStone;

import java.io.*;
import java.util.*;

/**
 * El problema de la piedra filosofal se soluciona con pilas, pues nos dice que Harry y Monk tienen bolsas de la misma clase, de las 
 * cuales sólo tienen acceso a la última moneda que hayan agregado. "Harry" nos indica que Harry lanza a Monk un moneda, "Remove" nos 
 * indica que se elimina la última moneda insertada en el bolso de Monk. Cuando "x" sea igual a la suma del valor de todas las monedas 
 * se debe imprimir la cantidad de monedas en el bolso de Monk. 
 * @author Brian Esteban Barreto Cardozo
 */
public class PhilosopherStone {
    Node head = null;
    
    /**
     * Verifica si la pila tiene elementos o no
     * @return false si la pila tiene elementos, de lo contrario true
     */
    public boolean isEmpty()
    {
        return head == null ? true : false;
    }
    
    /**
     * siguiendo los parámetros de las pilas, sólo se podrá insertar elementos al inicio, y este a su vez se convertirá en la cabeza.
     * @param newNode 
     */
    public void push(Node newNode) //insertar
    {
        newNode.next = head;
        head = newNode;
    }
    
    /**
     * Como se eleminará un elemento, la cabeza será ahora al que estaba apuntando, y se borrará el primer elemento.
     * @return la información del elemento eliminado.
     */
    public int pop() 
    {
        Node temp = head;
        head = head.next;
        
        int info=temp.value;
        temp = null;
        System.gc();
        return info;
    }

    /**
     * Realiza un recorrido de la pila, realizando la suma total del valor que registre el nodo.
     * @return suma total
     */
    public int sum()
    {
        if (isEmpty())
            return 0;
        
        else
        {
            int sum = 0;
            Node temp = head;
            while(temp.next != null)
            {
                sum += temp.value;
                temp = temp.next;
            }
            sum += temp.value;
            return sum;
        }
    }
    
    /**
     * Se crean dos pilas, la de Harry y la de Monk, se insertan n_coins en la pila bagHarry, mientras la suma de los valores de bagMonk
     * sea distinta a x, por cada instrucción de "Harry", este toma el valor de su ultimo nodo insertado y se inserta en bagMonk, además
     * de aumentar en uno la cantidad de monedas, por cada instrucción "Remove" se elimina el último elemento insertado en bagMonk y se
     * desminuye en uno la cantidad. Por ultimo se imprime la cantidad.
     * @param args 
     */
    public static void main(String[] args)
    {
        PhilosopherStone bagHarry = new PhilosopherStone();
        PhilosopherStone bagMonk = new PhilosopherStone();
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        Scanner sc = new Scanner(System.in);
        int n_coins = sc.nextInt();
        
        for (int i = 0; i < n_coins; i++) 
        {
            int value_coin = sc.nextInt();
            Node coins = new Node(value_coin);
            bagHarry.push(coins);
        }
        
        int n_instructions = sc.nextInt();  //Harry: moneda de Harry a Monk. Remove: elimina moneda de Monk
        int x = sc.nextInt();               //cuando duerme Monk
        int cantidad = 0;
        
        for (int i = 0; i < n_instructions; i++)
        {
            if(bagMonk.sum() != x)
            {
                String instruction = sc.next();
                if(instruction.equals("Harry"))
                {
                    int coinHarry = bagHarry.pop();
                    Node coinMonk = new Node(coinHarry);
                    bagMonk.push(coinMonk);
                    cantidad++;
                }
                else if (instruction.equals("Remove"))
                {
                    bagMonk.pop();
                    cantidad--;
                }
            }else
            {
                break;
            }
        }
        try {
            bw.write(cantidad);
        }
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
}

/*
//Entradas:
4
3 1 1 4
6 7
Harry
Harry
Harry
Remove
Remove
Harry
//Respuesta: 2
*/