
package WizardTournament;

import java.io.*;
import java.util.Scanner;

/**
 * El program del torneo de los magos consiste en seguir dos instrucciones clásicas en las filas, la primera instruccion es encolar
 * con la carateristica especial que los estudiantes de las escuelas queden agrupados, la segunda instruccion es desencolar común y corriente.
 * @author Brian Esteban Barreto Cardozo
 */
public class WizardTournament {
    Node head = null;
    
    /**
     * Si la cabeza está vacía es por que la cola está vacía
     * @return verdadero si está vacía, falso si tiene al menos un elemente
     */
    public boolean isEmpty()
    {
        return head == null;
    }
    
    /**
     * Desencola el elemento de la cabeza, de manera que temp es la nueva cabeza para no perder información, así:
     * se guarda la informacion de temp en una variable de tipo String info.
     * @return la información guardada en info, o sea el elemento desencolado.
     */
    public String dequeue()
    {
        Node temp = head;
        head = head.next;
        String info = temp.toString();
        temp = null;
        System.gc();
        return info;
    }
     
    /**
     * Si la fila está vacia el nuevo nodo será la cabeza, de lo contrario, verifica que el siguiente nodo no sea nulo y que el valor
     * "de la escuela" del nodo temporal sea menor o igual al del nuevo nodo, de manera que queden agrupados por escuelas.
     * @param newNode 
     */
    public void enqueue(Node newNode) 
    {
        if (isEmpty()) 
            head = newNode;
        else
        {
            Node temp = head;
            while((temp.next != null) && (newNode.school >= temp.next.school))
                temp = temp.next;
            
            newNode.next = temp.next;
            temp.next = newNode;
        }    
    }
        
    /**
     * Se crea la fila student, se hace un ciclo for que itere hasta el número de instrucciones indicado, se divide la instrucción por 
     * cada espacio que se deje en la cadena de caracteres con el metodo split() de manera que se descifre el primer caracter que será
     * trabajado en un switch case, si es "E" encola un nuevo nodo con los datos que también son tomados de la cadena, si la instruccion
     * es "D" simplemente se llama a la función que desencola y se imprimen los datos que arroje.
     * @param args
     * @throws IOException 
     */
    public static void main(String[] args) throws IOException {
        WizardTournament student = new WizardTournament();
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Scanner sc = new Scanner(System.in);
        
        int q = sc.nextInt();
       
        for (int i = 0; i < q; i++) {
            String instruction = br.readLine();
            String[] data = instruction.split(" ");
            switch(data[0])
            {
                case "E":
                    Node st = new Node(Integer.parseInt(data[1]), Integer.parseInt(data[2]));
                    student.enqueue(st);
                    break;
                case "D":
                    System.out.println(student.dequeue());
                    break;
                default:    
                    break;
            }       
        }
    }
}

/*
//Entradas:
5
E 1 1
E 2 1
E 1 2
D
D
//Respuesta:
1 1
1 2
*/